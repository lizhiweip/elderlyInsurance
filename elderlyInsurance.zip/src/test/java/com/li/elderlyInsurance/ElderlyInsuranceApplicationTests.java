package com.li.elderlyInsurance;

import com.li.mapper.MedicineMapper;
import com.li.pojo.Medicine;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElderlyInsuranceApplicationTests {

	@Test
	void contextLoads() {
		Medicine medicine = new Medicine();
	}

}
