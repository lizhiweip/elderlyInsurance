Page({
  handleContact (e) {
      console.log(e.detail)
  }
})
